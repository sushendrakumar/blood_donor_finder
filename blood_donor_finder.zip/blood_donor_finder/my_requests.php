<?php

require_once "config.php";


// Check login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION["user_id"];


// Get patient's blood requests
$stmt = $pdo->prepare("
    SELECT
        br.id,
        br.blood_group,
        br.units,
        br.hospital,
        br.location,
        br.contact,
        br.emergency,
        br.status,
        br.created_at,

        dr.status AS donor_status,

        d.name AS donor_name,
        d.mobile AS donor_mobile,
        d.blood_group AS donor_blood_group

    FROM blood_requests br

    LEFT JOIN donor_requests dr
        ON br.id = dr.blood_request_id
        AND dr.status = 'Accepted'

    LEFT JOIN users d
        ON dr.donor_id = d.id

    WHERE br.patient_id = ?

    ORDER BY br.created_at DESC
");

$stmt->execute([$user_id]);

$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Blood Requests</title>

    <link
        rel="stylesheet"
        href="assets/style.css"
    >

    <style>

        .request-box {
            background: white;
            border-radius: 20px;
            padding: 25px;
            margin: 25px auto;
            max-width: 800px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }

        .request-box h3 {
            color: #c90016;
            margin-bottom: 15px;
        }

        .request-box p {
            margin: 8px 0;
        }

        .status {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: bold;
            margin-top: 10px;
        }

        .pending {
            background: #fff3cd;
            color: #856404;
        }

        .found {
            background: #d4edda;
            color: #155724;
        }

        .completed {
            background: #cce5ff;
            color: #004085;
        }

        .donor-box {
            margin-top: 20px;
            padding: 18px;
            background: #f1fff4;
            border-radius: 15px;
            border-left: 5px solid #28a745;
        }

        .donor-box h4 {
            color: #168534;
            margin-top: 0;
        }

        .no-request {
            text-align: center;
            padding: 40px;
        }

    </style>

</head>


<body>


<!-- NAVBAR -->

<nav>

    <div class="logo">
        🩸 Blood Donor Finder
    </div>

    <div class="nav-links">

        <a href="index.php">
            Home
        </a>

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="logout.php">
            Logout
        </a>

    </div>

</nav>



<!-- CONTENT -->

<div class="container">

    <h2>
        My Blood Requests
    </h2>

    <p class="section-text">
        Check the current status of your blood requests.
    </p>


    <?php if (count($requests) == 0): ?>

        <div class="card no-request">

            <div class="card-icon">
                🩸
            </div>

            <h3>
                No Blood Requests
            </h3>

            <p>
                You have not created any blood requests yet.
            </p>

            <br>

            <a
                href="request_blood.php"
                class="btn"
            >
                Request Blood
            </a>

        </div>


    <?php else: ?>


        <?php foreach ($requests as $request): ?>


            <div class="request-box">


                <h3>
                    🩸
                    <?= htmlspecialchars($request["blood_group"]) ?>
                    Blood Request
                </h3>


                <p>
                    <strong>Units:</strong>
                    <?= htmlspecialchars($request["units"]) ?>
                </p>


                <p>
                    <strong>Hospital:</strong>
                    <?= htmlspecialchars($request["hospital"]) ?>
                </p>


                <p>
                    <strong>Location:</strong>
                    <?= htmlspecialchars($request["location"]) ?>
                </p>


                <p>
                    <strong>Contact:</strong>
                    <?= htmlspecialchars($request["contact"]) ?>
                </p>


                <?php if ($request["emergency"] == 1): ?>

                    <p>
                        🚨
                        <strong>Emergency Request</strong>
                    </p>

                <?php endif; ?>


                <!-- STATUS -->

                <?php if ($request["status"] == "Pending"): ?>

                    <div class="status pending">
                        ⏳ Waiting for Donor
                    </div>


                <?php elseif ($request["status"] == "Donor Found"): ?>

                    <div class="status found">
                        ✅ Donor Found
                    </div>


                <?php elseif ($request["status"] == "Completed"): ?>

                    <div class="status completed">
                        ✅ Completed
                    </div>


                <?php else: ?>

                    <div class="status">
                        <?= htmlspecialchars($request["status"]) ?>
                    </div>

                <?php endif; ?>



                <!-- DONOR INFORMATION -->

                <?php if (!empty($request["donor_name"])): ?>


                    <div class="donor-box">

                        <h4>
                            ❤️ Donor Accepted Your Request
                        </h4>


                        <p>
                            <strong>Donor Name:</strong>

                            <?= htmlspecialchars(
                                $request["donor_name"]
                            ) ?>

                        </p>


                        <p>
                            <strong>Blood Group:</strong>

                            <?= htmlspecialchars(
                                $request["donor_blood_group"]
                            ) ?>

                        </p>


                        <p>
                            <strong>Mobile:</strong>

                            <?= htmlspecialchars(
                                $request["donor_mobile"]
                            ) ?>

                        </p>


                    </div>


                <?php endif; ?>


            </div>


        <?php endforeach; ?>


    <?php endif; ?>


</div>


</body>

</html>