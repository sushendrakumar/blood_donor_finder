<?php

require_once "config.php";


// Check login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}


// Only donor can access
if ($_SESSION["role"] != "donor") {
    header("Location: dashboard.php");
    exit;
}


$donor_id = $_SESSION["user_id"];


// Get donor blood group
$donor_stmt = $pdo->prepare(
    "SELECT blood_group
     FROM users
     WHERE id = ?"
);

$donor_stmt->execute([$donor_id]);

$donor = $donor_stmt->fetch(PDO::FETCH_ASSOC);


if (!$donor) {
    die("Donor account not found.");
}


$blood_group = $donor["blood_group"];


// Get matching requests
$stmt = $pdo->prepare(
    "SELECT
        br.id,
        br.blood_group,
        br.units,
        br.hospital,
        br.location,
        br.contact,
        br.emergency,
        br.status,
        br.created_at,
        u.name AS patient_name

     FROM blood_requests br

     INNER JOIN users u
     ON br.patient_id = u.id

     WHERE br.status = 'Pending'

     AND br.blood_group = ?

     AND NOT EXISTS
     (
        SELECT 1
        FROM donor_requests dr
        WHERE dr.blood_request_id = br.id
        AND dr.donor_id = ?
        AND dr.status = 'Rejected'
     )

     ORDER BY br.emergency DESC,
              br.created_at DESC"
);


$stmt->execute([
    $blood_group,
    $donor_id
]);


$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Blood Requests
    </title>

    <link
        rel="stylesheet"
        href="assets/style.css"
    >

</head>


<body>


<!-- NAVBAR -->

<nav>

    <div class="logo">
        🩸 Blood Donor Finder
    </div>


    <div class="nav-links">

        <a href="index.php">
            Home
        </a>

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="logout.php">
            Logout
        </a>

    </div>

</nav>



<!-- CONTENT -->

<div class="container">


    <h2>
        Blood Requests
    </h2>


    <p class="section-text">

        Requests matching your blood group:
        <strong>
            <?= htmlspecialchars($blood_group) ?>
        </strong>

    </p>



    <?php if (count($requests) == 0): ?>


        <div class="card">

            <div class="card-icon">
                ❤️
            </div>


            <h3>
                No Pending Requests
            </h3>


            <p>
                There are currently no matching
                blood requests.
            </p>

        </div>


    <?php else: ?>


        <div class="cards">


            <?php foreach ($requests as $request): ?>


                <div class="card">


                    <div class="card-icon">
                        🚨
                    </div>


                    <h3>

                        <?= htmlspecialchars(
                            $request["blood_group"]
                        ) ?>

                        Blood Needed

                    </h3>


                    <p>

                        Patient:

                        <?= htmlspecialchars(
                            $request["patient_name"]
                        ) ?>

                    </p>


                    <p>

                        Units:

                        <?= htmlspecialchars(
                            $request["units"]
                        ) ?>

                    </p>


                    <p>

                        Hospital:

                        <?= htmlspecialchars(
                            $request["hospital"]
                        ) ?>

                    </p>


                    <p>

                        Location:

                        <?= htmlspecialchars(
                            $request["location"]
                        ) ?>

                    </p>


                    <p>

                        Contact:

                        <?= htmlspecialchars(
                            $request["contact"]
                        ) ?>

                    </p>


                    <?php if ($request["emergency"] == 1): ?>

                        <p>
                            🚨 <strong>Emergency</strong>
                        </p>

                    <?php endif; ?>



                    <!-- ACCEPT BUTTON -->

                    <form
                        method="POST"
                        action="respond_request.php"
                        style="display:inline;"
                    >

                        <input
                            type="hidden"
                            name="request_id"
                            value="<?= (int)$request["id"] ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="accept"
                        >

                        <button
                            type="submit"
                            class="btn"
                        >
                            Accept Request
                        </button>

                    </form>



                    <!-- REJECT BUTTON -->

                    <form
                        method="POST"
                        action="respond_request.php"
                        style="display:inline;"
                    >

                        <input
                            type="hidden"
                            name="request_id"
                            value="<?= (int)$request["id"] ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="reject"
                        >

                        <button
                            type="submit"
                            class="btn light-btn"
                        >
                            Reject
                        </button>

                    </form>


                </div>


            <?php endforeach; ?>


        </div>


    <?php endif; ?>


</div>


</body>

</html>