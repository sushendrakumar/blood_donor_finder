<?php

require_once "config.php";


if (!isset($_SESSION["user_id"])) {

    header("Location: login.php");

    exit;
}


$blood_group = "";

$location = "";


if (isset($_GET["blood_group"])) {

    $blood_group = $_GET["blood_group"];
}


if (isset($_GET["location"])) {

    $location = trim($_GET["location"]);
}


$donors = [];


if ($blood_group != "") {

    if ($location != "") {

        $stmt = $pdo->prepare(
            "SELECT id, name, mobile, blood_group, location
             FROM users
             WHERE role = 'donor'
             AND available = 1
             AND blood_group = ?
             AND location LIKE ?
             ORDER BY name"
        );

        $stmt->execute([
            $blood_group,
            "%" . $location . "%"
        ]);

    } else {

        $stmt = $pdo->prepare(
            "SELECT id, name, mobile, blood_group, location
             FROM users
             WHERE role = 'donor'
             AND available = 1
             AND blood_group = ?
             ORDER BY name"
        );

        $stmt->execute([$blood_group]);
    }


    $donors = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Find Donors</title>

    <link
        rel="stylesheet"
        href="assets/style.css"
    >

</head>

<body>


<nav>

    <div class="logo">
        🩸 Blood Donor Finder
    </div>

    <div class="nav-links">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="logout.php">
            Logout
        </a>

    </div>

</nav>


<div class="container">


    <h2>
        Find Blood Donors
    </h2>

    <p class="section-text">
        Search for available donors.
    </p>


    <div class="form-container">


        <form method="GET">


            <label>
                Blood Group
            </label>

            <select
                name="blood_group"
                required
            >

                <option value="">
                    Select Blood Group
                </option>

                <option
                    value="A+"
                    <?= $blood_group == "A+" ? "selected" : "" ?>
                >
                    A+
                </option>

                <option
                    value="A-"
                    <?= $blood_group == "A-" ? "selected" : "" ?>
                >
                    A-
                </option>

                <option
                    value="B+"
                    <?= $blood_group == "B+" ? "selected" : "" ?>
                >
                    B+
                </option>

                <option
                    value="B-"
                    <?= $blood_group == "B-" ? "selected" : "" ?>
                >
                    B-
                </option>

                <option
                    value="AB+"
                    <?= $blood_group == "AB+" ? "selected" : "" ?>
                >
                    AB+
                </option>

                <option
                    value="AB-"
                    <?= $blood_group == "AB-" ? "selected" : "" ?>
                >
                    AB-
                </option>

                <option
                    value="O+"
                    <?= $blood_group == "O+" ? "selected" : "" ?>
                >
                    O+
                </option>

                <option
                    value="O-"
                    <?= $blood_group == "O-" ? "selected" : "" ?>
                >
                    O-
                </option>

            </select>


            <label>
                Location
            </label>

            <input
                type="text"
                name="location"
                value="<?= htmlspecialchars($location) ?>"
                placeholder="Enter city / area"
            >


            <button
                type="submit"
                class="btn full-btn"
            >
                Search Donors
            </button>


        </form>


    </div>


    <?php if ($blood_group != ""): ?>


        <h2>
            Available Donors
        </h2>


        <?php if (count($donors) == 0): ?>

            <div class="card">

                <h3>
                    No Donors Found
                </h3>

                <p>
                    No available donor was found for
                    the selected blood group and location.
                </p>

            </div>


        <?php else: ?>


            <div class="cards">


                <?php foreach ($donors as $donor): ?>


                    <div class="card">


                        <div class="card-icon">
                            🩸
                        </div>


                        <h3>
                            <?= htmlspecialchars($donor["name"]) ?>
                        </h3>


                        <p>
                            Blood Group:
                            <strong>
                                <?= htmlspecialchars($donor["blood_group"]) ?>
                            </strong>
                        </p>


                        <p>
                            Location:
                            <?= htmlspecialchars($donor["location"]) ?>
                        </p>


                        <p>
                            Mobile:
                            <?= htmlspecialchars($donor["mobile"]) ?>
                        </p>


                    </div>


                <?php endforeach; ?>


            </div>


        <?php endif; ?>


    <?php endif; ?>


</div>


</body>
</html>