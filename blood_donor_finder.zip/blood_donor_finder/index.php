<?php
require_once "config.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Blood Donor Finder</title>

    <link rel="stylesheet" href="assets/style.css">

</head>

<body>


<!-- NAVBAR -->

<nav>

    <div class="logo">
        🩸 Blood Donor Finder
    </div>

    <div class="nav-links">

        <a href="index.php">Home</a>

        <?php if (isset($_SESSION["user_id"])): ?>

            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>

        <?php else: ?>

            <a href="login.php">Login</a>
            <a href="register.php">Register</a>

        <?php endif; ?>

    </div>

</nav>


<!-- HERO -->

<section class="hero">

    <div class="hero-content">

        <div class="blood-icon">
            🩸
        </div>

        <h1>
            Find Blood. Save Lives.
        </h1>

        <p>
            Quickly connect patients with available
            blood donors during emergency situations.
        </p>


        <div class="hero-buttons">


            <!-- BECOME A DONOR -->

            <button
                type="button"
                class="btn"
                onclick="goToRegister()"
            >
                🩸 Become a Donor
            </button>


            <!-- REQUEST BLOOD -->

            <button
                type="button"
                class="btn light-btn"
                onclick="goToRequestBlood()"
            >
                🚨 Request Blood
            </button>


        </div>

    </div>

</section>


<!-- HOW IT WORKS -->

<section class="container">

    <h2>
        How It Works
    </h2>

    <p class="section-text">
        Our platform makes it easier to find blood donors
        when every second matters.
    </p>


    <div class="cards">


        <div class="card">

            <div class="card-icon">
                👤
            </div>

            <h3>
                Register
            </h3>

            <p>
                Register yourself as a blood donor
                or patient.
            </p>

        </div>


        <div class="card">

            <div class="card-icon">
                🔎
            </div>

            <h3>
                Find Donors
            </h3>

            <p>
                Search for available blood donors
                based on blood group and location.
            </p>

        </div>


        <div class="card">

            <div class="card-icon">
                🚨
            </div>

            <h3>
                Emergency Request
            </h3>

            <p>
                Create an emergency blood request
                when blood is urgently required.
            </p>

        </div>


        <div class="card">

            <div class="card-icon">
                ❤️
            </div>

            <h3>
                Save Lives
            </h3>

            <p>
                Donors can respond and help patients
                during critical situations.
            </p>

        </div>


    </div>

</section>


<!-- FOOTER -->

<footer>

    <p>
        © 2026 Blood Donor Finder | Save Lives
    </p>

</footer>


<!-- BUTTON FUNCTIONS -->

<script>

function goToRegister() {

    window.location.href = "register.php";

}


function goToRequestBlood() {

    window.location.href = "request_blood.php";

}

</script>


</body>
</html>