<?php

require_once "config.php";


if (!isset($_SESSION["user_id"])) {

    header("Location: login.php");

    exit;
}


$user_id = $_SESSION["user_id"];


$stmt = $pdo->prepare(
    "SELECT * FROM users WHERE id = ?"
);

$stmt->execute([$user_id]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);


if (!$user) {

    session_destroy();

    header("Location: login.php");

    exit;
}

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Dashboard</title>

    <link
        rel="stylesheet"
        href="assets/style.css"
    >

</head>

<body>


<nav>

    <div class="logo">
        🩸 Blood Donor Finder
    </div>

    <div class="nav-links">

        <a href="index.php">
            Home
        </a>

        <a href="logout.php">
            Logout
        </a>

    </div>

</nav>


<div class="container dashboard">


    <h2>
        Welcome, <?= htmlspecialchars($user["name"]) ?>!
    </h2>


    <p class="section-text">

        You are logged in as

        <strong>
            <?= ucfirst($user["role"]) ?>
        </strong>

    </p>


    <div class="cards">


        <div class="card">

            <div class="card-icon">
                🩸
            </div>

            <h3>
                Blood Group
            </h3>

            <p>
                <?= htmlspecialchars($user["blood_group"]) ?>
            </p>

        </div>


        <div class="card">

            <div class="card-icon">
                📍
            </div>

            <h3>
                Location
            </h3>

            <p>
                <?= htmlspecialchars($user["location"]) ?>
            </p>

        </div>


        <?php if ($user["role"] == "patient"): ?>

            <div class="card">

                <div class="card-icon">
                    🚨
                </div>

                <h3>
                    Request Blood
                </h3>

                <p>
                    Need blood urgently?
                </p>

                <a
                    href="request_blood.php"
                    class="btn"
                >
                    Request Blood
                </a>

            </div>


            <div class="card">

                <div class="card-icon">
                    🔎
                </div>

                <h3>
                    Find Donors
                </h3>

                <p>
                    Search available donors.
                </p>

                <a
                    href="find_donors.php"
                    class="btn"
                >
                    Find Donors
                </a>

            </div>


            <div class="card">

                <div class="card-icon">
                    📋
                </div>

                <h3>
                    My Requests
                </h3>

                <p>
                    Check your blood requests.
                </p>

                <a
                    href="my_requests.php"
                    class="btn"
                >
                    View Requests
                </a>

            </div>

        <?php endif; ?>


        <?php if ($user["role"] == "donor"): ?>

            <div class="card">

                <div class="card-icon">
                    🚨
                </div>

                <h3>
                    Blood Requests
                </h3>

                <p>
                    See patients who need blood.
                </p>

                <a
                    href="donor_requests.php"
                    class="btn"
                >
                    View Requests
                </a>

            </div>

        <?php endif; ?>


    </div>


</div>


</body>
</html>