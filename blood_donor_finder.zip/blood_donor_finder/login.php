<?php

require_once "config.php";

$message = "";
$message_type = "";

if (isset($_GET["registered"])) {

    $message = "Registration successful! Please login.";
    $message_type = "success";
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $mobile = trim($_POST["mobile"]);
    $password = $_POST["password"];


    if ($mobile == "" || $password == "") {

        $message = "Please enter mobile number and password.";
        $message_type = "error";

    } else {

        $stmt = $pdo->prepare(
            "SELECT * FROM users
             WHERE mobile = ?
             LIMIT 1"
        );

        $stmt->execute([$mobile]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);


        if (
            $user &&
            password_verify(
                $password,
                $user["password"]
            )
        ) {

            $_SESSION["user_id"] = $user["id"];

            $_SESSION["name"] = $user["name"];

            $_SESSION["role"] = $user["role"];


            header("Location: dashboard.php");

            exit;

        } else {

            $message =
                "Invalid mobile number or password.";

            $message_type = "error";
        }
    }
}

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Login - Blood Donor Finder</title>

    <link
        rel="stylesheet"
        href="assets/style.css"
    >

</head>

<body>


<nav>

    <div class="logo">
        🩸 Blood Donor Finder
    </div>

    <div class="nav-links">

        <a href="index.php">
            Home
        </a>

        <a href="register.php">
            Register
        </a>

    </div>

</nav>


<div class="form-container">

    <h2>
        Welcome Back
    </h2>

    <p class="section-text">
        Login to continue
    </p>


    <?php if ($message != ""): ?>

        <div class="<?= $message_type ?>">

            <?= htmlspecialchars($message) ?>

        </div>

    <?php endif; ?>


    <form method="POST">


        <label>
            Mobile Number
        </label>

        <input
            type="text"
            name="mobile"
            placeholder="Enter mobile number"
            required
        >


        <label>
            Password
        </label>

        <input
            type="password"
            name="password"
            placeholder="Enter password"
            required
        >


        <button
            type="submit"
            class="btn full-btn"
        >
            Login
        </button>


    </form>


    <p class="form-bottom">

        Don't have an account?

        <a href="register.php">
            Create account
        </a>

    </p>

</div>


</body>
</html>