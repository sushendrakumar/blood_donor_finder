<?php

require_once "config.php";

$message = "";
$message_type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"] ?? "");
    $mobile = trim($_POST["mobile"] ?? "");
    $password = $_POST["password"] ?? "";
    $blood_group = $_POST["blood_group"] ?? "";
    $location = trim($_POST["location"] ?? "");
    $role = $_POST["role"] ?? "";


    // Check all fields
    if (
        $name == "" ||
        $mobile == "" ||
        $password == "" ||
        $blood_group == "" ||
        $location == "" ||
        $role == ""
    ) {

        $message = "Please fill all fields.";
        $message_type = "error";

    } else {

        // Check mobile number already exists
        $check = $pdo->prepare(
            "SELECT id FROM users WHERE mobile = ? LIMIT 1"
        );

        $check->execute([$mobile]);

        if ($check->fetch()) {

            $message = "This mobile number is already registered.";
            $message_type = "error";

        } else {

            // Encrypt password
            $hashed_password = password_hash(
                $password,
                PASSWORD_DEFAULT
            );


            // Insert user
            $stmt = $pdo->prepare(
                "INSERT INTO users
                (
                    name,
                    mobile,
                    password,
                    blood_group,
                    location,
                    role
                )
                VALUES (?, ?, ?, ?, ?, ?)"
            );


            $stmt->execute([
                $name,
                $mobile,
                $hashed_password,
                $blood_group,
                $location,
                $role
            ]);


            // Registration successful
            header("Location: login.php?registered=1");
            exit;
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Register - Blood Donor Finder
    </title>

    <link
        rel="stylesheet"
        href="assets/style.css"
    >

</head>


<body>


<!-- NAVBAR -->

<nav>

    <div class="logo">
        🩸 Blood Donor Finder
    </div>


    <div class="nav-links">

        <a href="index.php">
            Home
        </a>

        <a href="login.php">
            Login
        </a>

    </div>

</nav>


<!-- REGISTER FORM -->

<div class="form-container">


    <h2>
        Create Account
    </h2>


    <p class="section-text">
        Register as a Blood Donor or Patient
    </p>


    <!-- MESSAGE -->

    <?php if ($message != ""): ?>

        <div class="<?= $message_type ?>">

            <?= htmlspecialchars($message) ?>

        </div>

    <?php endif; ?>


    <!-- FORM -->

    <form method="POST">


        <!-- NAME -->

        <label>
            Full Name
        </label>

        <input
            type="text"
            name="name"
            placeholder="Enter your full name"
            required
        >


        <!-- MOBILE -->

        <label>
            Mobile Number
        </label>

        <input
            type="text"
            name="mobile"
            placeholder="Enter mobile number"
            maxlength="15"
            required
        >


        <!-- PASSWORD -->

        <label>
            Password
        </label>

        <input
            type="password"
            name="password"
            placeholder="Create password"
            required
        >


        <!-- BLOOD GROUP -->

        <label>
            Blood Group
        </label>

        <select
            name="blood_group"
            required
        >

            <option value="">
                Select Blood Group
            </option>

            <option value="A+">
                A+
            </option>

            <option value="A-">
                A-
            </option>

            <option value="B+">
                B+
            </option>

            <option value="B-">
                B-
            </option>

            <option value="AB+">
                AB+
            </option>

            <option value="AB-">
                AB-
            </option>

            <option value="O+">
                O+
            </option>

            <option value="O-">
                O-
            </option>

        </select>


        <!-- LOCATION -->

        <label>
            Location
        </label>

        <input
            type="text"
            name="location"
            placeholder="Enter city / area"
            required
        >


        <!-- ROLE -->

        <label>
            Register As
        </label>

        <select
            name="role"
            required
        >

            <option value="">
                Select Option
            </option>

            <option value="donor">
                Blood Donor
            </option>

            <option value="patient">
                Patient / Blood Seeker
            </option>

        </select>


        <!-- CREATE ACCOUNT -->

        <button
            type="submit"
            class="btn full-btn"
        >
            Create Account
        </button>


    </form>


    <!-- LOGIN LINK -->

    <p class="form-bottom">

        Already have an account?

        <a href="login.php">
            Login here
        </a>

    </p>


</div>


</body>

</html>