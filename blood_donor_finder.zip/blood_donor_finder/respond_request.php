<?php

require_once "config.php";


// Check login
if (!isset($_SESSION["user_id"])) {

    header("Location: login.php");

    exit;
}


// Only donor
if ($_SESSION["role"] != "donor") {

    header("Location: dashboard.php");

    exit;
}


// Only POST allowed
if ($_SERVER["REQUEST_METHOD"] != "POST") {

    header("Location: donor_requests.php");

    exit;
}


// Get values
$request_id = isset($_POST["request_id"])
    ? (int)$_POST["request_id"]
    : 0;

$action = $_POST["action"] ?? "";

$donor_id = $_SESSION["user_id"];



// Validate
if ($request_id <= 0) {

    die("Invalid blood request.");

}


if ($action != "accept" && $action != "reject") {

    die("Invalid action.");

}



try {


    // Get blood request
    $stmt = $pdo->prepare(
        "SELECT *
         FROM blood_requests
         WHERE id = ?"
    );

    $stmt->execute([$request_id]);

    $request = $stmt->fetch(PDO::FETCH_ASSOC);


    if (!$request) {

        die("Blood request not found.");

    }



    // Request must still be pending
    if ($request["status"] != "Pending") {

        die(
            "This request is no longer available. Current status: "
            . htmlspecialchars($request["status"])
        );

    }



    // Get donor
    $stmt = $pdo->prepare(
        "SELECT *
         FROM users
         WHERE id = ?
         AND role = 'donor'"
    );

    $stmt->execute([$donor_id]);

    $donor = $stmt->fetch(PDO::FETCH_ASSOC);


    if (!$donor) {

        die("Donor account not found.");

    }



    // Check blood group
    if ($donor["blood_group"] != $request["blood_group"]) {

        die(
            "Your blood group does not match this request."
        );

    }



    /* =========================
       ACCEPT REQUEST
       ========================= */

    if ($action == "accept") {


        // Start transaction
        $pdo->beginTransaction();


        // Save donor response
        $stmt = $pdo->prepare(
            "INSERT INTO donor_requests
            (
                blood_request_id,
                donor_id,
                status
            )
            VALUES (?, ?, 'Accepted')

            ON DUPLICATE KEY UPDATE
            status = 'Accepted'"
        );


        $stmt->execute([
            $request_id,
            $donor_id
        ]);



        // Change blood request status
        $stmt = $pdo->prepare(
            "UPDATE blood_requests
             SET status = 'Donor Found'
             WHERE id = ?
             AND status = 'Pending'"
        );


        $stmt->execute([
            $request_id
        ]);



        // Check whether update happened
        if ($stmt->rowCount() == 0) {

            $pdo->rollBack();

            die(
                "Unable to accept this request. "
                . "It may already have been accepted."
            );

        }


        // Finish transaction
        $pdo->commit();


        // Go back
        header(
            "Location: donor_requests.php?success=accepted"
        );

        exit;

    }



    /* =========================
       REJECT REQUEST
       ========================= */

    if ($action == "reject") {


        $stmt = $pdo->prepare(
            "INSERT INTO donor_requests
            (
                blood_request_id,
                donor_id,
                status
            )
            VALUES (?, ?, 'Rejected')

            ON DUPLICATE KEY UPDATE
            status = 'Rejected'"
        );


        $stmt->execute([
            $request_id,
            $donor_id
        ]);


        header(
            "Location: donor_requests.php?success=rejected"
        );

        exit;
    }


} catch (PDOException $e) {


    if ($pdo->inTransaction()) {

        $pdo->rollBack();

    }


    die(
        "Database error: "
        . htmlspecialchars($e->getMessage())
    );

}

?>