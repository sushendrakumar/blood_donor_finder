<?php

require_once "config.php";


if (!isset($_SESSION["user_id"])) {

    header("Location: login.php");

    exit;
}


if ($_SESSION["role"] != "patient") {

    header("Location: dashboard.php");

    exit;
}


$message = "";
$message_type = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $blood_group = $_POST["blood_group"];

    $units = (int) $_POST["units"];

    $hospital = trim($_POST["hospital"]);

    $location = trim($_POST["location"]);

    $contact = trim($_POST["contact"]);

    $emergency = isset($_POST["emergency"]) ? 1 : 0;


    if (
        $blood_group == "" ||
        $units < 1 ||
        $hospital == "" ||
        $location == "" ||
        $contact == ""
    ) {

        $message = "Please fill all fields.";

        $message_type = "error";

    } else {

        $stmt = $pdo->prepare(
            "INSERT INTO blood_requests
            (
                patient_id,
                blood_group,
                units,
                hospital,
                location,
                contact,
                emergency
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)"
        );


        $stmt->execute([

            $_SESSION["user_id"],

            $blood_group,

            $units,

            $hospital,

            $location,

            $contact,

            $emergency

        ]);


        $message =
            "Blood request created successfully!";

        $message_type = "success";
    }
}

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Request Blood</title>

    <link
        rel="stylesheet"
        href="assets/style.css"
    >

</head>

<body>


<nav>

    <div class="logo">
        🩸 Blood Donor Finder
    </div>

    <div class="nav-links">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="logout.php">
            Logout
        </a>

    </div>

</nav>


<div class="form-container">

    <h2>
        Emergency Blood Request
    </h2>

    <p class="section-text">
        Enter the details of the blood you need.
    </p>


    <?php if ($message != ""): ?>

        <div class="<?= $message_type ?>">

            <?= htmlspecialchars($message) ?>

        </div>

    <?php endif; ?>


    <form method="POST">


        <label>
            Blood Group
        </label>

        <select
            name="blood_group"
            required
        >

            <option value="">
                Select Blood Group
            </option>

            <option value="A+">A+</option>
            <option value="A-">A-</option>

            <option value="B+">B+</option>
            <option value="B-">B-</option>

            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>

            <option value="O+">O+</option>
            <option value="O-">O-</option>

        </select>


        <label>
            Number of Units
        </label>

        <input
            type="number"
            name="units"
            min="1"
            value="1"
            required
        >


        <label>
            Hospital Name
        </label>

        <input
            type="text"
            name="hospital"
            placeholder="Enter hospital name"
            required
        >


        <label>
            Location
        </label>

        <input
            type="text"
            name="location"
            placeholder="Enter hospital location"
            required
        >


        <label>
            Contact Number
        </label>

        <input
            type="text"
            name="contact"
            placeholder="Enter contact number"
            required
        >


        <label>

            <input
                type="checkbox"
                name="emergency"
                checked
            >

            This is an emergency request

        </label>


        <button
            type="submit"
            class="btn full-btn"
        >
            Submit Blood Request
        </button>


    </form>


</div>


</body>
</html>