<?php

require_once "../config.php";

if (
    !isset($_SESSION["user_id"]) ||
    $_SESSION["role"] != "patient"
) {

    header("Location: ../login.php");
    exit;

}

$stmt = $pdo->prepare(
    "SELECT *
     FROM blood_requests
     WHERE patient_id = ?
     ORDER BY created_at DESC"
);

$stmt->execute([$_SESSION["user_id"]]);

$requests = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>My Requests</title>

<link rel="stylesheet" href="../assets/style.css">

</head>

<body>

<nav>

<div class="logo">🩸 BloodConnect</div>

<div class="nav-links">

<a href="../dashboard.php">Dashboard</a>
<a href="../logout.php">Logout</a>

</div>

</nav>


<div class="container">

<h2>My Blood Requests</h2>


<div class="cards">

<?php if (!$requests): ?>

<div class="empty-box">

<h3>No Requests Yet</h3>

<p>
You have not created any blood requests.
</p>

</div>

<?php endif; ?>


<?php foreach ($requests as $request): ?>

<div class="card">

<div class="card-icon">🩸</div>

<h3>
REQ<?= htmlspecialchars($request["id"]) ?>
</h3>

<p>
<strong>Blood:</strong>
<?= htmlspecialchars($request["blood_group"]) ?>
</p>

<p>
<strong>Units:</strong>
<?= htmlspecialchars($request["units"]) ?>
</p>

<p>
<strong>Hospital:</strong>
<?= htmlspecialchars($request["hospital"]) ?>
</p>

<p>
<strong>Location:</strong>
<?= htmlspecialchars($request["location"]) ?>
</p>

<p>
<strong>Status:</strong>

<span class="status">
<?= htmlspecialchars($request["status"]) ?>
</span>

</p>

</div>

<?php endforeach; ?>

</div>

</div>

</body>
</html>