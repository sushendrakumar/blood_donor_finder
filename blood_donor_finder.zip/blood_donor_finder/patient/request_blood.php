<?php

require_once "../config.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "patient") {

    header("Location: ../login.php");
    exit;

}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $blood_group = $_POST["blood_group"];
    $units = intval($_POST["units"]);
    $hospital = trim($_POST["hospital"]);
    $location = trim($_POST["location"]);
    $contact = trim($_POST["contact"]);

    $emergency = isset($_POST["emergency"]) ? 1 : 0;

    $stmt = $pdo->prepare(
        "INSERT INTO blood_requests
        (patient_id,blood_group,units,hospital,location,contact,emergency)
        VALUES (?,?,?,?,?,?,?)"
    );

    $stmt->execute([
        $_SESSION["user_id"],
        $blood_group,
        $units,
        $hospital,
        $location,
        $contact,
        $emergency
    ]);

    $id = $pdo->lastInsertId();

    $message = "Blood request created successfully! Request ID: REQ" . $id;
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Request Blood</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="../assets/style.css">

</head>

<body>

<nav>

<div class="logo">🩸 BloodConnect</div>

<div class="nav-links">

<a href="../dashboard.php">Dashboard</a>
<a href="../logout.php">Logout</a>

</div>

</nav>


<div class="form-container">

<h2>Emergency Blood Request</h2>

<?php if ($message): ?>

<div class="success">
<?= htmlspecialchars($message) ?>
</div>

<?php endif; ?>


<form method="POST">

<label>Blood Group</label>

<select name="blood_group" required>

<option value="">Select Blood Group</option>

<option>A+</option>
<option>A-</option>
<option>B+</option>
<option>B-</option>
<option>AB+</option>
<option>AB-</option>
<option>O+</option>
<option>O-</option>

</select>


<label>Required Units</label>

<input type="number" name="units" min="1" value="1" required>


<label>Hospital Name</label>

<input type="text" name="hospital" required>


<label>Location</label>

<input type="text" name="location" required>


<label>Contact Number</label>

<input type="text" name="contact" required>


<label class="checkbox">

<input type="checkbox" name="emergency">

This is an emergency request

</label>


<button class="btn" type="submit">
Submit Blood Request
</button>

</form>

</div>

</body>
</html>